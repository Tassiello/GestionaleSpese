package GestioneSpese;

public class Categoria {
	private int idCategoria;
	private String nomeCategoria;
	private String descrizioneCategoria;
	
	public Categoria() {
	}
	
	public Categoria(String nomeCategoria, String descrizioneCategoria) {
		this.nomeCategoria = nomeCategoria;
		this.descrizioneCategoria = descrizioneCategoria;		
	}
	
	public Categoria(int idCategoria, String nomeCategoria, String descrizioneCategoria) {
		this.idCategoria = idCategoria;
		this.nomeCategoria = nomeCategoria;
		this.descrizioneCategoria = descrizioneCategoria;		
	}
	
	public int getIdCategoria() {
		return idCategoria;
	}
	
	public String getNomeCategoria () {
		return nomeCategoria;
	}
	
	public String getDescrizioneCategoria () {
		return descrizioneCategoria;
	}
	
	
	
	public void setIdCategoria (int idCategoria) {
		this.idCategoria = idCategoria;
	}
	
	public void setNomeCategoria (String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}
	
	public void setDescrizioneCategoria (String descrizioneCategoria) {
		this.descrizioneCategoria = descrizioneCategoria;
	}
	
	
	
    public String toSimpleString() {
        return  "Nome: " + nomeCategoria + ", Descrizione: " + descrizioneCategoria;
    }
	
	@Override
    public String toString() {
        return "ID: " + idCategoria + " , Nome: " + nomeCategoria + ", Descrizione: " + descrizioneCategoria;
    }
}
