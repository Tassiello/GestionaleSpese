package GestioneSpese;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSetup {
	public static final String URL = "jdbc:mysql://localhost:3306/";
	public static final String DB_NAME = "gestione_spese";
	public static String user;
	public static String password;
	

	public static void main(String[] args) {
		user = args[0];
		password = args[1];
		createDatabase();
		createTables();
	}
	
	private static void createDatabase() {
		String createDbQuery = "CREATE DATABASE IF NOT EXISTS " + DB_NAME;
		try(Connection conn = DriverManager.getConnection(URL, user, password);
			Statement stmt = conn.createStatement()){
			stmt.executeUpdate(createDbQuery);
			System.out.println("Database creato con successo!");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	private static void createTables() {
		
		String createCategoriaTable = "CREATE TABLE IF NOT EXISTS categorie ("
									+ "id_categoria INT AUTO_INCREMENT PRIMARY KEY, "
									+ "nome_categoria VARCHAR(50) NOT NULL, "
									+ "descrizione TEXT)";
		
		String createSpeseTable = "CREATE TABLE IF NOT EXISTS spese ("
								+ "id_spesa INT AUTO_INCREMENT PRIMARY KEY, "
								+ "nome_spesa VARCHAR(100) NOT NULL, "
								+ "data VARCHAR(50) NOT NULL, "
								+ "importo DECIMAL(10,2) NOT NULL, "
								+ "id_categoria INT)";
		
		
		
		try(Connection conn = DriverManager.getConnection(URL + DB_NAME, user, password);
				Statement stmt = conn.createStatement()){
			stmt.executeUpdate(createCategoriaTable);
			stmt.executeUpdate(createSpeseTable);
			insertDefaultCategories(stmt);
			System.out.println("Tabelle create con successo!");
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		
	}
	
    private static void insertDefaultCategories(Statement stmt) throws SQLException{
    	String checkCategoriesQuery = "SELECT COUNT(*) FROM categorie";
    	try(ResultSet rs = stmt.executeQuery(checkCategoriesQuery)){
    		if(rs.next()&& rs.getInt(1) == 0) {
    			String defaultCategorieTable = "INSERT INTO categorie (nome_categoria,descrizione) VALUES "
    	        		+ "('Salute','Spese per visite, medicinali'),"
    	        		+ "('Utenze e Tasse','Spese per Bollette e pagamento crediti statali'),"
    	        		+ "('Alimentari','Spese per alimentari'),"
    	        		+ "('Trasporto','Spese per trasporti pubblici, rifornimento'),"
    	        		+ "('Svago','Spese per uscite, ristorante, concerti'),"
    	        		+ "('Hobby','Spese per hobby vari')";
    			stmt.executeUpdate(defaultCategorieTable);
    			System.out.println("Default categories inserted.");
    		}else {
    			System.out.println("Default categories already exist.");
    		}
    	}
    }
	
	
	
	
	

}
