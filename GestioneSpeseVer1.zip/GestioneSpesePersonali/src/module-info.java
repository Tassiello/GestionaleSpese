/**
 * 
 */
/**
 * 
 */
module GestioneSpesePersonali {
	requires java.sql;
	requires java.desktop;
	requires pdfbox.app;
}