package GestioneSpese;

import javax.swing.*;


import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class GestionaleMain extends JFrame {
	
	Pdf pdf = new Pdf();
	private SpeseCRUD speseCrud;
	private JTextArea outputArea;
	private JTextArea outputAreaCategorie;
	private JTextArea outputFiltroCategorie;
    private JComboBox<String> categoriaSpesaComboBox;
    private JComboBox<String> categoriaUpdateComboBox;
	private JTextField idSpesaField, nomeSpesaField, importoField, dataField, categoriaSpesaField;
	private JTextField nomeCategoriaField, descrizioneCategoriaField;
	
	
	public GestionaleMain() {
		
		speseCrud = new SpeseCRUD();
		setupDatabase();
		
		setTitle("Gestione Spese");
		setSize(1024, 768);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTabbedPane tabbedPane = new JTabbedPane();
		
		JPanel spesePanel = new JPanel(new BorderLayout());
		//spesePanel.setLayout(new BorderLayout());
		setupSpesePanel(spesePanel);
		tabbedPane.addTab("Spese", spesePanel);
		
		JPanel categoriePanel = new JPanel(new BorderLayout());
		//spesePanel.setLayout(new BorderLayout());
		setupCategoriePanel(categoriePanel);
		tabbedPane.addTab("Categorie", categoriePanel);
		
		JPanel filtroCategoriePanel = new JPanel(new BorderLayout());
		//spesePanel.setLayout(new BorderLayout());
		setupFiltroCategoriePanel(filtroCategoriePanel);
		tabbedPane.addTab("Filtro per Categoria o Data", filtroCategoriePanel);
		
		JPanel deletePanel = new JPanel(new BorderLayout());
		setupDeletePanel(deletePanel);
		tabbedPane.addTab("Elimina", deletePanel);
		
		JPanel updatePanel = new JPanel(new BorderLayout());
		setupUpdatePanel(updatePanel);
		tabbedPane.addTab("Modifica", updatePanel);
		
		add(tabbedPane);
		
	}
	
	
	private void setupDatabase() {
		
		JPanel credenzialiPanel = new JPanel(new GridLayout(3,2));
		JTextField userField = new JTextField();
		JPasswordField passwordField = new JPasswordField();
		
		credenzialiPanel.add(new JLabel("Username Database:"));
		credenzialiPanel.add(userField);
		credenzialiPanel.add(new JLabel("Password Database:"));
		credenzialiPanel.add(passwordField);
		
        int result = JOptionPane.showConfirmDialog(null, credenzialiPanel, "Inserisci le Credenziali del Database", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String user = userField.getText();
            String password = new String(passwordField.getPassword());

            DatabaseConnection.setCredenziali(user, password);
            DatabaseSetup.main(new String[]{user, password});
        } else {
            System.exit(0);
        }
		
		
	}
	
	
	private void setupSpesePanel(JPanel panel) {
		
		outputArea = new JTextArea();
		JScrollPane scrollPane = new JScrollPane(outputArea);
		panel.add(scrollPane, BorderLayout.CENTER);
		
		JPanel inputPanel = new JPanel();
		inputPanel.setLayout(new GridLayout(5, 2));
		
		inputPanel.add(new JLabel("Nome Spesa:"));
		nomeSpesaField = new JTextField();
		inputPanel.add(nomeSpesaField);
		
		inputPanel.add(new JLabel("Importo:"));
		importoField = new JTextField();
		inputPanel.add(importoField);
		
		inputPanel.add(new JLabel("Data (YYYY-MM-DD):"));
		dataField = new JTextField();
		inputPanel.add(dataField);
		
		//inputPanel.add(new JLabel("Categoria:"));
		//categoriaSpesaField = new JTextField();
		//inputPanel.add(categoriaSpesaField);
		
        inputPanel.add(new JLabel("Categoria:"));
        categoriaSpesaComboBox = new JComboBox<>();
        populateCategoriaComboBox();
        inputPanel.add(categoriaSpesaComboBox);
		

        
        
		
		JButton btnAggiungi = new JButton("Aggiungi Spesa");
		btnAggiungi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
                try {
                    String nomeSpesa = nomeSpesaField.getText().trim();
                    String importoText = importoField.getText().trim();
                    String dataSpesa = dataField.getText().trim();
                    //String categoriaSpesa = categoriaSpesaField.getText().trim();
                    String categoriaSpesa = (String) categoriaSpesaComboBox.getSelectedItem();
                    
                    if (nomeSpesa.isEmpty() || importoText.isEmpty() || dataSpesa.isEmpty() || categoriaSpesa.isEmpty()) {
                        JOptionPane.showMessageDialog(panel, "Tutti i campi devono essere compilati", "Errore", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    double importoSpesa = Double.parseDouble(importoText);

                    speseCrud.addSpesa(nomeSpesa, dataSpesa, importoSpesa, categoriaSpesa);
                    JOptionPane.showMessageDialog(panel, "Spesa aggiunta con successo");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "L'importo deve essere un numero valido", "Errore", JOptionPane.ERROR_MESSAGE);
                }
                
//        		List<Spesa> spese = speseCrud.viewSpese(outputArea);
//        		StringBuilder sb = new StringBuilder();
//        		for (Spesa spesa : spese) {
//        			sb.append(spesa.toString()).append("\n");
//        		}
//        		outputArea.setText(sb.toString());
                updateSpeseOutput();
                
            }
        });
		
		inputPanel.add(new JLabel());
		
		inputPanel.add(btnAggiungi);
		
		panel.add(inputPanel, BorderLayout.NORTH);
		
		
//		List<Spesa> spese = speseCrud.viewSpese(outputArea);
//		StringBuilder sb = new StringBuilder();
//		for (Spesa spesa : spese) {
//			sb.append(spesa.toString()).append("\n");
//		}
//		outputArea.setText(sb.toString());
	
		updateSpeseOutput();
		
		JPanel buttonPanel = new JPanel(new FlowLayout());
		//buttonPanel.setLayout(new FlowLayout());
		
		JButton btnViewSpese = new JButton("Spese per ID");
		btnViewSpese.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
//				List<Spesa> spese = speseCrud.viewSpese(outputArea);
//				StringBuilder sb = new StringBuilder();
//				for (Spesa spesa : spese) {
//					sb.append(spesa.toString()).append("\n");
//				}
//				outputArea.setText(sb.toString());
				updateSpeseOutput();
			}
		});
		
		JButton btnPdfAllSpese = new JButton("PDF per ID");
		
        //PANNELLO PER BOTTONI ORDINE DATA
        //JPanel westSortPanel = new JPanel(new FlowLayout());
        JButton btnSortDataCrescente = new JButton(("Spese Per Data Crescente"));
		btnSortDataCrescente.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				
				List<Spesa> speseOrdinateCrescente = speseCrud.viewSpesePerDataCrescente();
				updateSpeseOutput(speseOrdinateCrescente);
			}
		});
        
		JButton btnPdfSpeseCrescente = new JButton("PDF data crescente");
		
		btnPdfSpeseCrescente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pdf.stampaSpesePerDataCrescente();
                JOptionPane.showMessageDialog(panel, "PDF Scaricato con successo!");
            }
        });
		
        
        JButton btnSortDataDecrescente = new JButton("Spese Per Data Decrescente");
        
		btnSortDataDecrescente.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				
				List<Spesa> speseOrdinateDecrescente = speseCrud.viewSpesePerDataDecrescente();
				updateSpeseOutput(speseOrdinateDecrescente);
			}
		});
		
		JButton btnPdfSpeseDecrescente = new JButton("PDF data decrescente");
		
		btnPdfSpeseDecrescente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pdf.stampaSpesePerDataDecrescente();
                JOptionPane.showMessageDialog(panel, "PDF Scaricato con successo!");
            }
        });
        
//        westSortPanel.add(sortDataCrescente);
//        westSortPanel.add(sortDataDecrescente);
        buttonPanel.add(btnSortDataDecrescente,new FlowLayout());
        buttonPanel.add(btnPdfSpeseDecrescente, new FlowLayout());
        buttonPanel.add(btnSortDataCrescente, new FlowLayout());
        buttonPanel.add(btnPdfSpeseCrescente, new FlowLayout());
		
		JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
		centerPanel.add(btnViewSpese);
		
//		buttonPanel.setLayout(new FlowLayout());
//		
//		buttonPanel.add(btnViewSpese);
		
		//buttonPanel.add(westSortPanel, BorderLayout.WEST);
		
		buttonPanel.add(centerPanel, BorderLayout.CENTER);
		
		buttonPanel.add(btnPdfAllSpese, BorderLayout.EAST);

		btnPdfAllSpese.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pdf.salvaPdf();
                JOptionPane.showMessageDialog(panel, "PDF Scaricato con successo!");
            }
        });
		
		
		panel.add(buttonPanel, BorderLayout.SOUTH);		
		
	}
	
	public void setupCategoriePanel(JPanel panel) {
		
		outputAreaCategorie = new JTextArea();
		JScrollPane scrollPaneCategoria = new JScrollPane(outputAreaCategorie);
		panel.add(scrollPaneCategoria, BorderLayout.CENTER);
		
		JPanel inputPanelCategoria = new JPanel();
		inputPanelCategoria.setLayout(new GridLayout(3, 2));
		
		inputPanelCategoria.add(new JLabel("Nome Categoria Personalizzata:"));
		nomeCategoriaField = new JTextField();
		inputPanelCategoria.add(nomeCategoriaField);
		
		inputPanelCategoria.add(new JLabel("Descrizione Categoria Personalizzata:"));
		descrizioneCategoriaField = new JTextField();
		inputPanelCategoria.add(descrizioneCategoriaField);
		

		
		
		JButton btnAddCategoria = new JButton("Aggiungi Categoria");
		
		btnAddCategoria.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String nomeNewCategoria = nomeCategoriaField.getText();
				String descrizioneNewCategoria = descrizioneCategoriaField.getText();
				
                if (nomeNewCategoria.isEmpty() || descrizioneNewCategoria.isEmpty()) {
                    JOptionPane.showMessageDialog(panel, "Tutti i campi devono essere compilati", "Errore", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
				Categoria nuovaCategoria = new Categoria(nomeNewCategoria, descrizioneNewCategoria);
				speseCrud.addCategoria(nuovaCategoria);
				outputAreaCategorie.setText("Categoria Personalizzata aggiunta correttamente! \n\n" + nuovaCategoria.toSimpleString());
				//populateCategoriaComboBox();
				
				updateAllCategoriaComboBoxes();
                updateCategorieOutput(outputAreaCategorie);
			}
		});
		
		inputPanelCategoria.add(new JLabel());
		
		inputPanelCategoria.add(btnAddCategoria);
		
		panel.add(inputPanelCategoria, BorderLayout.NORTH);
		
		updateCategorieOutput(outputAreaCategorie);
		
		List<Categoria> categorie = speseCrud.viewCategorie(outputAreaCategorie);
		speseCrud.viewCategorie(outputAreaCategorie);
		 StringBuilder sb = new StringBuilder();
            for (Categoria cat : categorie) {
                sb.append(cat.toString()).append("\n");
            }
            outputAreaCategorie.setText(sb.toString());
		
		JPanel buttonPanelCategoria = new JPanel();
		buttonPanelCategoria.setLayout(new FlowLayout());
		
		JButton btnViewCategorie = new JButton("Visualizza Categorie");
		btnViewCategorie.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				List<Categoria> categorie = speseCrud.viewCategorie(outputAreaCategorie);
				speseCrud.viewCategorie(outputAreaCategorie);
				 StringBuilder sb = new StringBuilder();
		            for (Categoria cat : categorie) {
		                sb.append(cat.toString()).append("\n");
		            }
		            outputAreaCategorie.setText(sb.toString());
			}
		});
		buttonPanelCategoria.add(btnViewCategorie);
		
		panel.add(buttonPanelCategoria, BorderLayout.SOUTH);
		
		
		
		
	}
	
	
	private void setupFiltroCategoriePanel(JPanel panel) {
	    panel.setLayout(new BorderLayout());
	    
	    JPanel inputPanel = new JPanel();
	    inputPanel.setLayout(new GridLayout(3, 2));
	    
	    JTextField categoriaField = new JTextField();
	    JTextField dataField = new JTextField("YYYY-MM-DD");
	    
	    inputPanel.add(new JLabel("Nome Categoria:"));
	    inputPanel.add(categoriaField);
	    
	    inputPanel.add(new JLabel("Data (YYYY-MM-DD):"));
	    inputPanel.add(dataField);
	    
	    JButton btnFiltraCategoria = new JButton("Filtra per Categoria");
	    JButton btnFiltraData = new JButton("Filtra per Data");
	    
	    btnFiltraCategoria.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            String nomeCategoria = categoriaField.getText().trim();
	            if (!nomeCategoria.isEmpty()) {
	                List<Spesa> speseFiltrate = speseCrud.filtraSpesePerCategoria(nomeCategoria);
	                updateFiltroCategorieOutput(speseFiltrate);
	            } else {
	                JOptionPane.showMessageDialog(panel, "Inserisci il nome della categoria da filtrare", "Errore", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    });
	    
	    btnFiltraData.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            String data = dataField.getText().trim();
	            if (isValidDate(data)) {
	                List<Spesa> speseFiltrate = speseCrud.filtraSpesePerData(data);
	                updateFiltroCategorieOutput(speseFiltrate);
	            } else {
	                JOptionPane.showMessageDialog(panel, "Inserisci una data nel formato corretto (YYYY-MM-DD)", "Errore", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    });
	    
	    inputPanel.add(btnFiltraCategoria);
	    inputPanel.add(btnFiltraData);
	    
	    panel.add(inputPanel, BorderLayout.NORTH);
	    
	    outputFiltroCategorie = new JTextArea();
	    JScrollPane scrollPane = new JScrollPane(outputFiltroCategorie);
	    panel.add(scrollPane, BorderLayout.CENTER);
	    
	    // Metodo per inizializzare e visualizzare le spese
	    updateFiltroCategorieOutput(speseCrud.viewSpese(outputFiltroCategorie));
	}

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private void updateFiltroCategorieOutput(List<Spesa> spese) {
	    StringBuilder sb = new StringBuilder();
	    for (Spesa spesa : spese) {
	        sb.append(spesa.toString()).append("\n");
	    }
	    outputFiltroCategorie.setText(sb.toString());
	}

	private boolean isValidDate(String dateStr) {
	    // Metodo per verificare il formato della data
	    // Implementazione personalizzata a seconda del formato desiderato
	    return dateStr.matches("\\d{4}-\\d{2}-\\d{2}");
	}
	
	
	private void updateAllCategoriaComboBoxes() {
	    // Aggiorna la combobox della sezione "Aggiungi Spesa"
	    populateCategoriaComboBox(categoriaSpesaComboBox);

	    // Aggiorna la combobox della sezione "Modifica Spesa"
	    populateCategoriaComboBox(categoriaUpdateComboBox);
	}
	
    private void populateCategoriaComboBox() {
        categoriaSpesaComboBox.removeAllItems();
        List<Categoria> categorie = speseCrud.getCategorie();
        for (Categoria categoria : categorie) {
            categoriaSpesaComboBox.addItem(categoria.getNomeCategoria());
        }
    }
    
    private void populateCategoriaComboBox(JComboBox<String> comboBox) {
        comboBox.removeAllItems();
        List<Categoria> categorie = speseCrud.getCategorie();
        for (Categoria categoria : categorie) {
            comboBox.addItem(categoria.getNomeCategoria());
        }
        
    }
    
    private void updateSpeseOutput() {
        List<Spesa> spese = speseCrud.viewSpese(outputArea);
        StringBuilder sb = new StringBuilder();
        for (Spesa spesa : spese) {
            sb.append(spesa.toString()).append("\n");
        }
        outputArea.setText(sb.toString());
    }
    
    private void updateSpeseOutput(List<Spesa> spese) {
        StringBuilder sb = new StringBuilder();
        for (Spesa spesa : spese) {
            sb.append(spesa.toString()).append("\n");
        }
        outputArea.setText(sb.toString());
    }
    
    private void updateCategorieOutput(JTextArea outputAreaCategorie) {
        List<Categoria> categorie = speseCrud.viewCategorie(outputAreaCategorie);
        StringBuilder sb = new StringBuilder();
        for (Categoria cat : categorie) {
            sb.append(cat.toString()).append("\n");
        }
        outputAreaCategorie.setText(sb.toString());
    }
	
	
    private void setupDeletePanel(JPanel panel) {
        panel.setLayout(new BorderLayout());
        
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(2, 3)); 
        
        JTextField idSpesaField = new JTextField();
        JTextField idCategoriaField = new JTextField();
        
        inputPanel.add(new JLabel("ID Spesa da eliminare:"));
        inputPanel.add(idSpesaField);
        
        JButton btnEliminaSpesa = new JButton("Elimina Spesa");
        btnEliminaSpesa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int idSpesa = Integer.parseInt(idSpesaField.getText().trim());
                    speseCrud.deleteSpesa(idSpesa);
                    updateSpeseOutput(); 
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Inserisci un ID Spesa valido", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        inputPanel.add(btnEliminaSpesa);
        
        inputPanel.add(new JLabel("ID Categoria da eliminare:"));
        inputPanel.add(idCategoriaField);
        
        JButton btnEliminaCategoria = new JButton("Elimina Categoria");
        
        btnEliminaCategoria.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int idCategoria = Integer.parseInt(idCategoriaField.getText().trim());
                    if (idCategoria <= 6) {
                        JOptionPane.showMessageDialog(panel, "Non è possibile eliminare questa Categoria", "Errore", JOptionPane.ERROR_MESSAGE);
                    } else {
                        speseCrud.deleteCategoria(idCategoria);
                        JOptionPane.showMessageDialog(panel, "Categoria Numero " + idCategoria + " eliminata correttamente");
                        //populateCategoriaComboBox();
                        updateAllCategoriaComboBoxes();
                        
                        updateCategorieOutput(outputAreaCategorie);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Inserisci un ID Categoria valido", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        inputPanel.add(btnEliminaCategoria);
        
        panel.add(inputPanel, BorderLayout.CENTER);
    }	
	
	
//    private void setupUpdatePanel(JPanel panel) {
//        panel.setLayout(new BorderLayout());
//        
//        JTextArea outputUpdateArea = new JTextArea();
//        JScrollPane scrollPane = new JScrollPane(outputUpdateArea);
//        panel.add(scrollPane, BorderLayout.CENTER);
//
//        JPanel inputPanel = new JPanel();
//        inputPanel.setLayout(new GridLayout(7, 2));
//
//        // Campi per aggiornare la spesa
//        inputPanel.add(new JLabel("ID Spesa:"));
//        JTextField idSpesaUpdateField = new JTextField();
//        inputPanel.add(idSpesaUpdateField);
//
//        inputPanel.add(new JLabel("Nome Spesa:"));
//        JTextField nomeSpesaUpdateField = new JTextField();
//        inputPanel.add(nomeSpesaUpdateField);
//
//        inputPanel.add(new JLabel("Importo:"));
//        JTextField importoUpdateField = new JTextField();
//        inputPanel.add(importoUpdateField);
//
//        inputPanel.add(new JLabel("Data (YYYY-MM-DD):"));
//        JTextField dataUpdateField = new JTextField();
//        inputPanel.add(dataUpdateField);
//
//        inputPanel.add(new JLabel("Categoria:"));
//        JComboBox<String> categoriaUpdateComboBox = new JComboBox<>();
//        this.categoriaUpdateComboBox = categoriaUpdateComboBox;
//        updateAllCategoriaComboBoxes();
//        inputPanel.add(categoriaUpdateComboBox);
//
//        // Campi per aggiornare la categoria
//        inputPanel.add(new JLabel("ID Categoria:"));
//        JTextField idCategoriaUpdateField = new JTextField();
//        inputPanel.add(idCategoriaUpdateField);
//
//        inputPanel.add(new JLabel("Nome Categoria:"));
//        JTextField nomeCategoriaUpdateField = new JTextField();
//        inputPanel.add(nomeCategoriaUpdateField);
//
//        inputPanel.add(new JLabel("Descrizione Categoria:"));
//        JTextField descrizioneCategoriaUpdateField = new JTextField();
//        inputPanel.add(descrizioneCategoriaUpdateField);
//
//        JButton btnUpdateSpesa = new JButton("Aggiorna Spesa");
//        btnUpdateSpesa.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                try {
//                    int idSpesa = Integer.parseInt(idSpesaUpdateField.getText().trim());
//                    String nomeSpesa = nomeSpesaUpdateField.getText().trim();
//                    double importoSpesa = Double.parseDouble(importoUpdateField.getText().trim());
//                    String dataSpesa = dataUpdateField.getText().trim();
//                    String categoriaSpesa = (String) categoriaUpdateComboBox.getSelectedItem();
//
//                    Spesa spesa = new Spesa(idSpesa, nomeSpesa, dataSpesa, importoSpesa, categoriaSpesa, "");
//                    speseCrud.updateSpesa(idSpesa, spesa);
//                    outputUpdateArea.setText("Spesa aggiornata correttamente: \n" + spesa.toString());
//                    updateSpeseOutput();
//                } catch (NumberFormatException ex) {
//                    JOptionPane.showMessageDialog(panel, "Inserisci valori validi per ID Spesa e Importo", "Errore", JOptionPane.ERROR_MESSAGE);
//                }
//            }
//        });
//
//        JButton btnUpdateCategoria = new JButton("Aggiorna Categoria");
//        btnUpdateCategoria.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                try {
//                    int idCategoria = Integer.parseInt(idCategoriaUpdateField.getText().trim());
//                    String nomeCategoria = nomeCategoriaUpdateField.getText().trim();
//                    String descrizioneCategoria = descrizioneCategoriaUpdateField.getText().trim();
//
//                    Categoria categoria = new Categoria(idCategoria, nomeCategoria, descrizioneCategoria);
//                    speseCrud.updateCategoria(idCategoria, categoria);
//                    outputUpdateArea.setText("Categoria aggiornata correttamente: \n" + categoria.toString());
//                    updateAllCategoriaComboBoxes();
//                    updateCategorieOutput(outputAreaCategorie);
//                } catch (NumberFormatException ex) {
//                    JOptionPane.showMessageDialog(panel, "Inserisci un ID Categoria valido", "Errore", JOptionPane.ERROR_MESSAGE);
//                }
//            }
//        });
//
//        inputPanel.add(new JLabel());
//        inputPanel.add(btnUpdateSpesa);
//        inputPanel.add(new JLabel());
//        inputPanel.add(btnUpdateCategoria);
//
//        panel.add(inputPanel, BorderLayout.NORTH);
//    }


    
    
    private void setupUpdatePanel(JPanel panel) {
        panel.setLayout(new BorderLayout());

        // TextArea per i messaggi
        JTextArea outputUpdateArea = new JTextArea();
        outputUpdateArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputUpdateArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Pannello degli input
        JPanel inputPanel = new JPanel(new GridLayout(7, 4, 10, 10));

        // Campi per aggiornare la spesa
        inputPanel.add(new JLabel("ID Spesa:"));
        JTextField idSpesaUpdateField = new JTextField();
        inputPanel.add(idSpesaUpdateField);

        inputPanel.add(new JLabel("ID Categoria:"));
        JTextField idCategoriaUpdateField = new JTextField();
        inputPanel.add(idCategoriaUpdateField);

        inputPanel.add(new JLabel("Nome Spesa:"));
        JTextField nomeSpesaUpdateField = new JTextField();
        inputPanel.add(nomeSpesaUpdateField);

        inputPanel.add(new JLabel("Nome Categoria:"));
        JTextField nomeCategoriaUpdateField = new JTextField();
        inputPanel.add(nomeCategoriaUpdateField);

        inputPanel.add(new JLabel("Importo:"));
        JTextField importoUpdateField = new JTextField();
        inputPanel.add(importoUpdateField);

        inputPanel.add(new JLabel("Descrizione Categoria:"));
        JTextField descrizioneCategoriaUpdateField = new JTextField();
        inputPanel.add(descrizioneCategoriaUpdateField);

        inputPanel.add(new JLabel("Data (YYYY-MM-DD):"));
        JTextField dataUpdateField = new JTextField();
        inputPanel.add(dataUpdateField);

        inputPanel.add(new JLabel());
        inputPanel.add(new JLabel());

        inputPanel.add(new JLabel("Categoria:"));
        JComboBox<String> categoriaUpdateComboBox = new JComboBox<>();
        this.categoriaUpdateComboBox = categoriaUpdateComboBox;
        updateAllCategoriaComboBoxes();
        inputPanel.add(categoriaUpdateComboBox);

        JButton btnUpdateSpesa = new JButton("Aggiorna Spesa");
        btnUpdateSpesa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int idSpesa = Integer.parseInt(idSpesaUpdateField.getText().trim());
                    String nomeSpesa = nomeSpesaUpdateField.getText().trim();
                    double importoSpesa = Double.parseDouble(importoUpdateField.getText().trim());
                    String dataSpesa = dataUpdateField.getText().trim();
                    String categoriaSpesa = (String) categoriaUpdateComboBox.getSelectedItem();

                    Spesa spesa = new Spesa(idSpesa, nomeSpesa, dataSpesa, importoSpesa, categoriaSpesa, "");
                    speseCrud.updateSpesa(idSpesa, spesa);
                    outputUpdateArea.setText("Spesa aggiornata correttamente: \n" + spesa.toString());
                    updateSpeseOutput();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Inserisci valori validi per ID Spesa e Importo", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton btnUpdateCategoria = new JButton("Aggiorna Categoria");
        btnUpdateCategoria.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int idCategoria = Integer.parseInt(idCategoriaUpdateField.getText().trim());
                if (idCategoria <= 6) {
                    JOptionPane.showMessageDialog(panel, "Non è possibile eliminare questa Categoria", "Errore", JOptionPane.ERROR_MESSAGE);
                } else {
                try {
                    
                    String nomeCategoria = nomeCategoriaUpdateField.getText().trim();
                    String descrizioneCategoria = descrizioneCategoriaUpdateField.getText().trim();

                    Categoria categoria = new Categoria(idCategoria, nomeCategoria, descrizioneCategoria);
                    speseCrud.updateCategoria(idCategoria, categoria);
                    outputUpdateArea.setText("Categoria aggiornata correttamente: \n" + categoria.toString());
                    updateAllCategoriaComboBoxes();
                    updateCategorieOutput(outputAreaCategorie);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Inserisci un ID Categoria valido", "Errore", JOptionPane.ERROR_MESSAGE);
                }
               }
            }
        });

        inputPanel.add(new JLabel());
        inputPanel.add(btnUpdateCategoria);
        //inputPanel.add(btnUpdateSpesa);
        inputPanel.add(new JLabel());
        inputPanel.add(btnUpdateSpesa);
        //inputPanel.add(btnUpdateCategoria);

        panel.add(inputPanel, BorderLayout.NORTH);
    }

    
    

    
    
    
    

	

	public static void main(String[] args) {
		
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GestionaleMain().setVisible(true);
            }
        });
		
		
		
		
	}

}
