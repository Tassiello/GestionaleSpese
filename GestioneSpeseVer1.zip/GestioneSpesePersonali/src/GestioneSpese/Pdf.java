package GestioneSpese;

import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import java.sql.*;
import java.io.IOException;

public class Pdf {

	public void salvaPdf(){
	//public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/gestione_spese";
		String user = "root";
		String password = "B4n4n4Spl1t!";
		try (
				//Connection conn = DatabaseConnection.getConnection();
				Connection conn = DriverManager.getConnection(url, user, password);
				Statement stmt = conn.createStatement();
				){
			
			//Query di estrazione 
			String query = "SELECT spese.id_spesa, spese.nome_spesa, spese.data, spese.importo, categorie.nome_categoria "
					+ "FROM spese "
					+ "JOIN categorie ON spese.id_categoria = categorie.id_categoria";
			ResultSet rs = stmt.executeQuery(query);
			
			//Creazione del documento pdf
			PDDocument document = new PDDocument();
			PDPage page = new PDPage(PDRectangle.A4);
			document.addPage(page);
			
			//apertura del contentStream
			PDPageContentStream contentStream = new PDPageContentStream(document, page);
			
			//impostiamo il font e il testo del documento
			contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);
			contentStream.beginText();
			contentStream.newLineAtOffset(220, 750);
			contentStream.showText("Spese");
			contentStream.endText();
			
			contentStream.setFont(PDType1Font.HELVETICA, 12);
			
			//Definiamo la tabella che conterrÃ  i dati
			//Intestazione tabella
			float yPosition = 700;
			contentStream.beginText();
			contentStream.newLineAtOffset(50, yPosition);
			contentStream.showText("Nome Spesa");
			contentStream.newLineAtOffset(200, 0);
			contentStream.showText("Data Spesa");
			contentStream.newLineAtOffset(150, 0);
			contentStream.showText("Importo");
			contentStream.newLineAtOffset(100, 0);
			contentStream.showText("Categoria");
			contentStream.endText();
			
			yPosition -= 20;
			//lettura da rs e scrittura su pdf
			while(rs.next()) {
				String nome = rs.getString("nome_spesa");
				String data = rs.getString("data");
				double importo = rs.getDouble("importo");
				String nomeCategoria = rs.getString("nome_categoria");
				
				//puntiamo sul pdf
				contentStream.beginText();
				contentStream.newLineAtOffset(50, yPosition);
				contentStream.showText(nome);
				contentStream.newLineAtOffset(200, 0);
				contentStream.showText(data);
				contentStream.newLineAtOffset(150, 0);
				contentStream.showText(String.format("%.2f",importo));
				contentStream.newLineAtOffset(100, 0);
				contentStream.showText(nomeCategoria);
				contentStream.endText();
				
				yPosition -= 20;
				
			}
			
			//chiusura dello stream
			contentStream.close();
			
			//salvataggio del documento
			document.save("Fattura.pdf");
			
			//chiusura documento
			document.close();
			
			System.out.println("Fattura creata con successo!");			
			
		}catch(SQLException | IOException e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	public void stampaSpesePerDataCrescente() {
	    String url = "jdbc:mysql://localhost:3306/gestione_spese";
	    String user = "root";
	    String password = "B4n4n4Spl1t!";
	    try (Connection conn = DriverManager.getConnection(url, user, password);
	         Statement stmt = conn.createStatement()) {

	        // Query di estrazione ordinata per data crescente
	        String query = "SELECT spese.id_spesa, spese.nome_spesa, spese.data, spese.importo, categorie.nome_categoria "
	                     + "FROM spese "
	                     + "JOIN categorie ON spese.id_categoria = categorie.id_categoria "
	                     + "ORDER BY spese.data ASC";
	        ResultSet rs = stmt.executeQuery(query);

	        // Creazione del documento pdf
	        PDDocument document = new PDDocument();
	        PDPage page = new PDPage(PDRectangle.A4);
	        document.addPage(page);

	        // Apertura del contentStream
	        PDPageContentStream contentStream = new PDPageContentStream(document, page);

	        // Impostiamo il font e il testo del documento
	        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);
	        contentStream.beginText();
	        contentStream.newLineAtOffset(220, 750);
	        contentStream.showText("Spese ordinate per data crescente");
	        contentStream.endText();

	        contentStream.setFont(PDType1Font.HELVETICA, 12);

	        // Definiamo la tabella che conterrà i dati
	        float yPosition = 700;
	        contentStream.beginText();
	        contentStream.newLineAtOffset(50, yPosition);
	        contentStream.showText("Nome Spesa");
	        contentStream.newLineAtOffset(200, 0);
	        contentStream.showText("Data Spesa");
	        contentStream.newLineAtOffset(150, 0);
	        contentStream.showText("Importo");
	        contentStream.newLineAtOffset(100, 0);
	        contentStream.showText("Categoria");
	        contentStream.endText();

	        yPosition -= 20;
	        // Lettura da ResultSet e scrittura su pdf
	        while (rs.next()) {
	            String nome = rs.getString("nome_spesa");
	            String data = rs.getString("data");
	            double importo = rs.getDouble("importo");
	            String nomeCategoria = rs.getString("nome_categoria");

	            // Puntiamo sul pdf
	            contentStream.beginText();
	            contentStream.newLineAtOffset(50, yPosition);
	            contentStream.showText(nome);
	            contentStream.newLineAtOffset(200, 0);
	            contentStream.showText(data);
	            contentStream.newLineAtOffset(150, 0);
	            contentStream.showText(String.format("%.2f", importo));
	            contentStream.newLineAtOffset(100, 0);
	            contentStream.showText(nomeCategoria);
	            contentStream.endText();

	            yPosition -= 20;
	        }

	        // Chiusura dello stream
	        contentStream.close();

	        // Salvataggio del documento
	        document.save("Spese_Ordinate_Per_Data_Crescente.pdf");

	        // Chiusura documento
	        document.close();

	        System.out.println("Fattura creata con successo!");

	    } catch (SQLException | IOException e) {
	        e.printStackTrace();
	    }
	}

	
	
	
	
	
	
	public void stampaSpesePerDataDecrescente() {
	    String url = "jdbc:mysql://localhost:3306/gestione_spese";
	    String user = "root";
	    String password = "B4n4n4Spl1t!";
	    try (Connection conn = DriverManager.getConnection(url, user, password);
	         Statement stmt = conn.createStatement()) {

	        // Query di estrazione ordinata per data decrescente
	        String query = "SELECT spese.id_spesa, spese.nome_spesa, spese.data, spese.importo, categorie.nome_categoria "
	                     + "FROM spese "
	                     + "JOIN categorie ON spese.id_categoria = categorie.id_categoria "
	                     + "ORDER BY spese.data DESC";
	        ResultSet rs = stmt.executeQuery(query);

	        // Creazione del documento pdf
	        PDDocument document = new PDDocument();
	        PDPage page = new PDPage(PDRectangle.A4);
	        document.addPage(page);

	        // Apertura del contentStream
	        PDPageContentStream contentStream = new PDPageContentStream(document, page);

	        // Impostiamo il font e il testo del documento
	        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);
	        contentStream.beginText();
	        contentStream.newLineAtOffset(220, 750);
	        contentStream.showText("Spese ordinate per data decrescente");
	        contentStream.endText();

	        contentStream.setFont(PDType1Font.HELVETICA, 12);

	        // Definiamo la tabella che conterrà i dati
	        float yPosition = 700;
	        contentStream.beginText();
	        contentStream.newLineAtOffset(50, yPosition);
	        contentStream.showText("Nome Spesa");
	        contentStream.newLineAtOffset(200, 0);
	        contentStream.showText("Data Spesa");
	        contentStream.newLineAtOffset(150, 0);
	        contentStream.showText("Importo");
	        contentStream.newLineAtOffset(100, 0);
	        contentStream.showText("Categoria");
	        contentStream.endText();

	        yPosition -= 20;
	        // Lettura da ResultSet e scrittura su pdf
	        while (rs.next()) {
	            String nome = rs.getString("nome_spesa");
	            String data = rs.getString("data");
	            double importo = rs.getDouble("importo");
	            String nomeCategoria = rs.getString("nome_categoria");

	            // Puntiamo sul pdf
	            contentStream.beginText();
	            contentStream.newLineAtOffset(50, yPosition);
	            contentStream.showText(nome);
	            contentStream.newLineAtOffset(200, 0);
	            contentStream.showText(data);
	            contentStream.newLineAtOffset(150, 0);
	            contentStream.showText(String.format("%.2f", importo));
	            contentStream.newLineAtOffset(100, 0);
	            contentStream.showText(nomeCategoria);
	            contentStream.endText();

	            yPosition -= 20;
	        }

	        // Chiusura dello stream
	        contentStream.close();

	        // Salvataggio del documento
	        document.save("Spese_Ordinate_Per_Data_Decrescente.pdf");

	        // Chiusura documento
	        document.close();

	        System.out.println("Fattura creata con successo!");

	    } catch (SQLException | IOException e) {
	        e.printStackTrace();
	    }
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}