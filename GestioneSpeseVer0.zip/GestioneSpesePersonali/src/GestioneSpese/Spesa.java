package GestioneSpese;

public class Spesa {
	private int idSpesa;
	private String nomeSpesa;
	private double importo;
	private String data;
	private int idCategoria;
	private String nomeCategoria;
	private String descrizioneCategoria;
	
	
	public Spesa(){
	}
	
	public Spesa(String nomeSpesa, double importo, String data, int idCategoria) {
		this.nomeSpesa = nomeSpesa;
		this.importo = importo;
		this.data = data;
		this.idCategoria = idCategoria;
	}
	
	public Spesa(int idSpesa, String nomeSpesa, double importo, String data, int idCategoria) {
		this.idSpesa = idSpesa;
		this.nomeSpesa = nomeSpesa;
		this.importo = importo;
		this.data = data;
		this.idCategoria = idCategoria;
	}
	
	
	public Spesa(int idSpesa, String nomeSpesa, String data, double importo, String nomeCategoria, String descrizioneCategoria) {
		this.idSpesa = idSpesa;
		this.nomeSpesa = nomeSpesa;		
		this.data = data;
		this.importo = importo;
		this.nomeCategoria = nomeCategoria;
		this.descrizioneCategoria = descrizioneCategoria;
	}

	public int getIdSpesa() {
		return idSpesa;
	}
	
	public String getNomeSpesa() {
		return nomeSpesa;
	}
	
	public double  getImporto() {
		return importo;
	}
	
	public String getData() {
		return data;
	}
	
	public int getIdCategoria() {
		return idCategoria;
	}
	
    public String getNomeCategoria() {
        return nomeCategoria;
    }
	
	public void setIDSpesa(int idSpesa) {
		this.idSpesa = idSpesa;
	}
	
	public void setNomeSpesa(String nomeSpesa) {
		this.nomeSpesa = nomeSpesa;
	}
	
	public void setImporto(double importo) {
		this.importo = importo;
	}
	
	public void setData(String data) {
		this.data = data;
	}
	
	
	
	@Override
    public String toString() {
        return "ID: " + idSpesa + " , Nome Spesa: " + nomeSpesa + " , Importo: " + importo + " , Data: " + data + " , Categoria: " + nomeCategoria + ", Descrizione: " + descrizioneCategoria;
    }
	
	
	
}
