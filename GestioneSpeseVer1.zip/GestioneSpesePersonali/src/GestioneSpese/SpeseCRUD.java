package GestioneSpese;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

public class SpeseCRUD {
	
	
	
	public void addCategoria(Categoria categoria) {
		String query = "INSERT INTO categorie(nome_categoria, descrizione) VALUES (?, ?)";
		try(Connection conn = DatabaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1,  categoria.getNomeCategoria());
			pstmt.setString(2, categoria.getDescrizioneCategoria());
			pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updateCategoria(int idCategoria, Categoria categoria) {
	    String query = "UPDATE categorie SET nome_categoria = ?, descrizione = ? WHERE id_categoria = ?";
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(query)) {
	        pstmt.setString(1, categoria.getNomeCategoria());
	        pstmt.setString(2, categoria.getDescrizioneCategoria());
	        pstmt.setInt(3, idCategoria);
	        pstmt.executeUpdate();
	        JOptionPane.showMessageDialog(null, "Categoria aggiornata correttamente");
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Errore durante l'aggiornamento della categoria", "Errore", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
    public void updateSpesa(int idSpesa, Spesa spesa) {
        String query = "UPDATE spese SET nome_spesa = ?, data = ?, importo = ?, id_categoria = (SELECT id_categoria FROM categorie WHERE nome_categoria = ?) WHERE id_spesa = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, spesa.getNomeSpesa());
            pstmt.setString(2, spesa.getData());
            pstmt.setDouble(3, spesa.getImporto());
            pstmt.setString(4, spesa.getNomeCategoria());
            pstmt.setInt(5, idSpesa);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Spesa aggiornata correttamente");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errore durante l'aggiornamento della spesa", "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }
	
	
	
	
	public void deleteCategoria(int idCategoria) {
		String query = "DELETE FROM categorie WHERE id_categoria = ?";
		try(Connection conn = DatabaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, idCategoria);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteSpesa(int idSpesa) {
	    String query = "DELETE FROM spese WHERE id_spesa = ?";
	    
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(query)) {
	        
	        pstmt.setInt(1, idSpesa);
	        pstmt.executeUpdate();
	        
	        JOptionPane.showMessageDialog(null, "Spesa eliminata correttamente");
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Errore durante l'eliminazione della spesa", "Errore", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
	
	public Categoria getCategoriaPerNome(String nomeCategoria) {
		
	    String query = "SELECT id_categoria, nome_categoria, descrizione FROM categorie WHERE nome_categoria = ?";
	    Categoria categoria = null;
	    
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(query)) {
	        
	        stmt.setString(1, nomeCategoria);
	        ResultSet rs = stmt.executeQuery();
	        
	        if (rs.next()) {
	            int idCategoria = rs.getInt("id_categoria");
	            String descrizioneCategoria = rs.getString("descrizione");
	            
	            categoria = new Categoria(idCategoria, nomeCategoria, descrizioneCategoria);
	        }
	        
	        rs.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    
	    return categoria;
	}		
		
		
	
	
	public List<Spesa> viewSpese(JTextArea outputArea){
		List<Spesa> spese = new ArrayList<>();
		String query = "SELECT spese.id_spesa, spese.nome_spesa, spese.data, spese.importo, categorie.nome_categoria, categorie.descrizione "
					+ "FROM spese "
					+ "JOIN categorie ON spese.id_categoria = categorie.id_categoria";
		try(Connection connection = DatabaseConnection.getConnection();
				Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery(query)) {
			while(rs.next()) {
				int idSpesa = rs.getInt("id_spesa");
				String nomeSpesa = rs.getString("nome_spesa");
				String data = rs.getString("data");
				double importo = rs.getDouble("importo");
				String nomeCategoria = rs.getString("nome_categoria");
				String descrizioneCategoria = rs.getString("descrizione");
				
				spese.add(new Spesa(idSpesa, nomeSpesa, data, importo, nomeCategoria, descrizioneCategoria));
				
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return spese;
		
	}
	
	
	 public List<Spesa> filtraSpesePerCategoria(String nomeCategoria) {
	        List<Spesa> speseFiltrate = new ArrayList<>();
	        String query = "SELECT spese.id_spesa, spese.nome_spesa, spese.data, spese.importo, categorie.nome_categoria, categorie.descrizione "
	                     + "FROM spese "
	                     + "JOIN categorie ON spese.id_categoria = categorie.id_categoria "
	                     + "WHERE categorie.nome_categoria = ?";
	        
	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            
	            pstmt.setString(1, nomeCategoria);
	            ResultSet rs = pstmt.executeQuery();
	            
	            while (rs.next()) {
	                int idSpesa = rs.getInt("id_spesa");
	                String nomeSpesa = rs.getString("nome_spesa");
	                String data = rs.getString("data");
	                double importo = rs.getDouble("importo");
	                String categoria = rs.getString("nome_categoria");
	                String descrizioneCategoria = rs.getString("descrizione");
	                
	                speseFiltrate.add(new Spesa(idSpesa, nomeSpesa, data, importo, categoria, descrizioneCategoria));
	            }
	            
	            rs.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	        return speseFiltrate;
	}
	
	 public List<Spesa> filtraSpesePerData(String data) {
		    List<Spesa> speseFiltrate = new ArrayList<>();
		    String query = "SELECT spese.id_spesa, spese.nome_spesa, spese.data, spese.importo, categorie.nome_categoria, categorie.descrizione "
		                 + "FROM spese "
		                 + "JOIN categorie ON spese.id_categoria = categorie.id_categoria "
		                 + "WHERE spese.data = ?";
		    
		    try (Connection conn = DatabaseConnection.getConnection();
		         PreparedStatement pstmt = conn.prepareStatement(query)) {
		        
		        pstmt.setString(1, data);
		        ResultSet rs = pstmt.executeQuery();
		        
		        while (rs.next()) {
		            int idSpesa = rs.getInt("id_spesa");
		            String nomeSpesa = rs.getString("nome_spesa");
		            String dataSpesa = rs.getString("data");
		            double importo = rs.getDouble("importo");
		            String nomeCategoria = rs.getString("nome_categoria");
		            String descrizioneCategoria = rs.getString("descrizione");
		            
		            speseFiltrate.add(new Spesa(idSpesa, nomeSpesa, dataSpesa, importo, nomeCategoria, descrizioneCategoria));
		        }
		        
		        rs.close();
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    
		    return speseFiltrate;
		}
	
	
	public List<Categoria> viewCategorie(JTextArea outputAreaCategorie) {
		List<Categoria> categorie = new ArrayList<>();
		String query = "SELECT * FROM categorie";
		
		try(Connection conn = DatabaseConnection.getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(query)){
			
			while(rs.next()) {
				int idCategoria = rs.getInt("id_categoria");
				String nomeCategoria = rs.getString("nome_categoria");
				String descrizioneCategoria = rs.getString("descrizione");
				
				categorie.add(new Categoria(idCategoria, nomeCategoria, descrizioneCategoria));
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return categorie;
		
	}
	
	
    public List<Categoria> getCategorie() {
        List<Categoria> categorie = new ArrayList<>();
        String query = "SELECT id_categoria, nome_categoria, descrizione FROM categorie";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                int idCategoria = rs.getInt("id_categoria");
                String nomeCategoria = rs.getString("nome_categoria");
                String descrizioneCategoria = rs.getString("descrizione");
                categorie.add(new Categoria(idCategoria, nomeCategoria, descrizioneCategoria));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categorie;
    }
	
	public void addSpesa(String nomeSpesa, String data, double importo, String categoria) {
		String  query = "INSERT INTO spese(nome_spesa, data, importo, id_categoria) VALUES (?, ?, ?, ("
						+ "SELECT id_categoria FROM categorie WHERE nome_categoria = ?))";
		try(Connection conn = DatabaseConnection.getConnection();
				PreparedStatement pstmtSpesa = conn.prepareStatement(query)) {
			
				pstmtSpesa.setString(1, nomeSpesa);
				pstmtSpesa.setString(2, data);
				pstmtSpesa.setDouble(3, importo);
				pstmtSpesa.setString(4, categoria);
				
				pstmtSpesa.executeUpdate();
				
				
	}catch(SQLException e) {
		e.printStackTrace();
	}

	}
	
	
	
	
	
	
	public List<Spesa> viewSpesePerDataCrescente() {
	    List<Spesa> spese = new ArrayList<>();
	    String query = "SELECT spese.id_spesa, spese.nome_spesa, spese.data, spese.importo, categorie.nome_categoria, categorie.descrizione "
	                 + "FROM spese "
	                 + "JOIN categorie ON spese.id_categoria = categorie.id_categoria "
	                 + "ORDER BY spese.data ASC";
	    try(Connection connection = DatabaseConnection.getConnection();
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery(query)) {
	        
	        while(rs.next()) {
	            int idSpesa = rs.getInt("id_spesa");
	            String nomeSpesa = rs.getString("nome_spesa");
	            String data = rs.getString("data");
	            double importo = rs.getDouble("importo");
	            String nomeCategoria = rs.getString("nome_categoria");
	            String descrizioneCategoria = rs.getString("descrizione");
	            
	            spese.add(new Spesa(idSpesa, nomeSpesa, data, importo, nomeCategoria, descrizioneCategoria));
	        }
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    
	    return spese;
	}

	public List<Spesa> viewSpesePerDataDecrescente() {
	    List<Spesa> spese = new ArrayList<>();
	    String query = "SELECT spese.id_spesa, spese.nome_spesa, spese.data, spese.importo, categorie.nome_categoria, categorie.descrizione "
	                 + "FROM spese "
	                 + "JOIN categorie ON spese.id_categoria = categorie.id_categoria "
	                 + "ORDER BY spese.data DESC";
	    try(Connection connection = DatabaseConnection.getConnection();
	        Statement stmt = connection.createStatement();
	        ResultSet rs = stmt.executeQuery(query)) {
	        
	        while(rs.next()) {
	            int idSpesa = rs.getInt("id_spesa");
	            String nomeSpesa = rs.getString("nome_spesa");
	            String data = rs.getString("data");
	            double importo = rs.getDouble("importo");
	            String nomeCategoria = rs.getString("nome_categoria");
	            String descrizioneCategoria = rs.getString("descrizione");
	            
	            spese.add(new Spesa(idSpesa, nomeSpesa, data, importo, nomeCategoria, descrizioneCategoria));
	        }
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    
	    return spese;
	}


	
	
	
	
	
	
	
	
	
	
	
	
}
